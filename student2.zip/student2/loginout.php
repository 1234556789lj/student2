<?php
header("content-type:text/html;charset=utf-8");
if (!isset($_SESSION)) {
    session_start();
}

echo "<script>alert('退出成功');parent.location.href='login.php';</script>";

// 销毁会话信息
session_destroy();
?>
