<!-- <?php
header("content-type:text/html;charset=utf-8");
session_start();

if (!isset($_REQUEST['username']) || !isset($_POST['usertype'])) {
    header("location:login.php");
} else {
    $username = $_POST['username'];
    $passcode = $_POST['passcode'];
    $yz = $_POST['code'];
    $code = $_SESSION["code"];
    $password2 = sha1($passcode);
    require_once 'dbconfig.php';

    $usertype = $_POST['usertype'];

    $sql = "SELECT * FROM user WHERE username= '$username' AND password='$password2'";
    $result = mysql_query($sql, $conn);

    if ($row = mysql_fetch_array($result)) {
        if ($yz == $code) {
            $_SESSION['userName'] = $username;

            // 从数据库获取角色
            $role = $row['role'];

            if ($usertype == 'admin' && $role == 'admin') {
                // 管理员登录，重定向到管理员页面
                header("location:index.php");
            } elseif ($usertype == 'student' && $role == 'student') {
                // 学生登录，重定向到学生页面
                header("location:student_page.php");
            } else {
                // 用户类型与角色不匹配，处理错误
                echo "<script>alert('用户类型或角色错误！');parent.location.href='login.php';</script>";
            }
        } else {
            echo "<script>alert('验证码错误！');parent.location.href='login.php';</script>";
        }
    } else {
        echo "<script>alert('用户名或密码错误！');parent.location.href='login.php';</script>";
    }
}
?>
 -->




 <?php
header("content-type:text/html;charset=utf-8");
session_start();

if (!isset($_REQUEST['username']) || !isset($_POST['usertype'])) {
    header("location:login.php");
} else {
    $username = $_POST['username'];
    $passcode = $_POST['passcode'];
    $yz = $_POST['code'];
    $code = $_SESSION["code"];
    require_once 'dbconfig.php';

    $usertype = $_POST['usertype'];

    // 使用预处理语句防止 SQL 注入
    $sql = "SELECT * FROM user WHERE username= ? AND password= ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $username, sha1($passcode));
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_array($result)) {
        if ($yz == $code) {
            $_SESSION['userName'] = $username;

            // 从数据库获取角色
            $role = $row['role'];

            if ($usertype == 'admin' && $role == 'admin') {
                // 管理员登录，重定向到管理员页面
                header("location:index.php");
            } elseif ($usertype == 'student' && $role == 'student') {
                // 学生登录，重定向到学生页面
                header("location:student_page.php");
            } else {
                // 用户类型与角色不匹配，处理错误
                echo "<script>alert('用户类型或角色错误！');parent.location.href='login.php';</script>";
            }
        } else {
            echo "<script>alert('验证码错误！');parent.location.href='login.php';</script>";
        }
    } else {
        echo "<script>alert('用户名或密码错误！');parent.location.href='login.php';</script>";
    }
}
?>
