<?php
header ( "content-type:text/html;charset=utf-8" );
if (! isset ( $_SESSION )) {
	session_start ();
}
if (! isset ( $_SESSION['userName'] )) {
	header ( "location:login.php" );
} else {
	$Sno = $_REQUEST['Sno'];
	require_once 'dbconfig.php';
	$sql = "delete from body_info where Sno='$Sno'";
	$result = mysql_query ( $sql, $conn );
	if ($result) {
		echo "<script>alert('删除成功!');parent.location.href='bodyinfo.php';</script>";
		
	} else {
		echo "<script>alert('删除失败!');parent.location.href='bodyinfo.php';</script>";
		
	}
}
?>