<?php
session_start();

// 检查用户是否登录，未登录则跳转到登录页面
if (!isset($_SESSION['userName'])) {
    header("location: login.php");
    exit();
}

require_once 'dbconfig.php';

// 获取学生的个人信息
$query = "SELECT * FROM student WHERE Sno = '" . $_SESSION['userName'] . "'";
$result = mysql_query($query);
$row = mysql_fetch_assoc($result);

// 获取学生的体测数据
$queryBodyInfo = "SELECT * FROM body_info WHERE Sno = '" . $row['Sno'] . "'";
$resultBodyInfo = mysql_query($queryBodyInfo);
$healthSuggestions = array();

// 处理每个体测项目的数据
while ($rowBodyInfo = mysql_fetch_assoc($resultBodyInfo)) {
    $height = $rowBodyInfo['high'];
    $weight = $rowBodyInfo['weight'];
    $fhl = $rowBodyInfo['fhl'];
    $wsm = $rowBodyInfo['wsm'];
    $ldty = $rowBodyInfo['ldty'];

    // 根据体测数据生成健康建议
    $height_suggestion = ($height < 160) ? "建议注意保持适当运动，注意饮食平衡。" : "无特殊建议";
    $weight_suggestion = ($weight > 70) ? "建议控制饮食，适当参加有氧运动。" : "无特殊建议";
    $fhl_suggestion = ($fhl < 3000) ? "建议进行更多有氧运动，提升肺活量。" : "无特殊建议";
    $wsm_suggestion = ($wsm > 10) ? "建议注意加强短跑训练，提高速度。" : "无特殊建议";
    $ldty_suggestion = ($ldty < 2) ? "建议进行腿部力量训练，提高跳远能力。" : "无特殊建议";

    // 将建议添加到数组
    $healthSuggestions[] = array(
        'Height_Suggestion' => $height_suggestion,
        'Weight_Suggestion' => $weight_suggestion,
        'FHL_Suggestion' => $fhl_suggestion,
        'WSM_Suggestion' => $wsm_suggestion,
        'LDTY_Suggestion' => $ldty_suggestion
    );
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>学生个人信息</title>
    <!-- 引入样式文件 -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/custom.css" rel="stylesheet" />
</head>
<body>
    <!-- 页面内容 -->
    <div id="page-wrapper">
        <div id="page-inner">
            <!-- 显示学生个人信息 -->
            <!-- 在学生页面中添加登出按钮 -->
            <a href="loginout.php" class="btn btn-danger">退出登录</a>
            &nbsp;<a href='newpassword.php' class="btn btn-success">修改密码</a>&nbsp;
            <h2>学生个人信息</h2>
            <p><strong>姓名：</strong><?php echo $row['name']; ?></p>
            <p><strong>学号：</strong><?php echo $row['Sno']; ?></p>
            <p><strong>年级：</strong><?php echo $row['className']; ?></p>

            <!-- 显示学生健康建议 -->
            <h2>学生健康建议</h2>
            <table class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th>体测项目</th>
                        <th>体测结果</th>
                        <th>健康建议</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
foreach ($healthSuggestions as $suggestion) {
    echo "<tr>";
    echo "<td>身高</td>";
    echo "<td>" . $height . "cm</td>";
    echo "<td>" . $suggestion['Height_Suggestion'] . "</td>";
    echo "</tr>";

    echo "<tr>";
    echo "<td>体重</td>";
    echo "<td>" . $weight . "kg</td>";
    echo "<td>" . $suggestion['Weight_Suggestion'] . "</td>";
    echo "</tr>";

    echo "<tr>";
    echo "<td>肺活量</td>";
    echo "<td>" . $fhl . "ml</td>";
    echo "<td>" . $suggestion['FHL_Suggestion'] . "</td>";
    echo "</tr>";

    echo "<tr>";
    echo "<td>50米跑</td>";
    echo "<td>" . $wsm . "m/s</td>";
    echo "<td>" . $suggestion['WSM_Suggestion'] . "</td>";
    echo "</tr>";

    echo "<tr>";
    echo "<td>立定跳远</td>";
    echo "<td>" . $ldty. "m</td>";
    echo "<td>" . $suggestion['LDTY_Suggestion'] . "</td>";
    echo "</tr>";
}
?>


                </tbody>
            </table>
        </div>
    </div>

    <!-- 引入脚本文件 -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/custom.js"></script>
</body>
</html>
