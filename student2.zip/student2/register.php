<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>注册页面</title>
</head>
<body>
	<h1 align='center'>欢迎注册</h1>
	<hr>
	<form action="registerdo.php" method='post'>
		<label>学号：</label><input type='text' name='username' /> <label>密码：</label><input
			type='text' name='password' /> <input type='submit' name='hh'
			value='提交' />
	</form>
</body>
</html>