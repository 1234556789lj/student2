<?php
require_once 'dbconfig.php';
header("content-type:text/html;charset=utf-8");
//取表单数据
$Sno=$_REQUEST['Sno'];
$Sname=$_REQUEST['Sname'];
$high = $_REQUEST ['high'];
$weight = $_REQUEST ['weight'];
$fhl = $_REQUEST ['fhl'];
$wsm = $_REQUEST ['wsm'];
$ldty = $_REQUEST ['ldty'];


//sql语句中字符串数据类型都要加引号，数字字段随便
$sql = "INSERT INTO body_info(Sno,Sname,high,weight,fhl,wsm,ldty) VALUES ('$Sno','$Sname','$high','$weight','$fhl' ,'$wsm','$ldty')";
//exit($sql);

if(mysql_query($sql)){
	echo "<script>alert('学生体质信息添加成功！！！');parent.location.href='bodyinfo.php';</script>";
	
}else{
	echo "<script>alert('学生体质信息添加失败！！！');parent.location.href='bodyinfo.php';</script>";
	
}


