<?php
require_once 'dbconfig.php';
header("content-type:text/html;charset=utf-8");
//取表单数据
$username = $_REQUEST['username'];
$password = $_REQUEST['password'];
$password2 = sha1($password);

//sql语句中字符串数据类型都要加引号，数字字段随便
$sql = "INSERT INTO user(id, username, password, role) VALUES (null,'$username','$password2','admin')";
//exit($sql);

if(mysql_query($sql)){
	echo "<script>alert('添加成功！去登录');parent.location.href='login.php';</script>";
}else{
	echo "<script>alert('添加失败！！');parent.location.href='addAdmin.php';</script>";
}


