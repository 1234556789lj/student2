<?php require_once 'base.php';?>

<?php
require_once 'dbconfig.php';

// 获取学生数据
$query = "SELECT * FROM body_info";
$result = mysql_query($query);
?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h2>学生健康信息</h2>
            </div>
        </div>
        <!-- /. ROW  -->
        <hr />
        <div class="row">
            <div class="col-md-12">
                <!-- Advanced Tables -->
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>学号</th>
                                        <th>姓名</th>
                                        <th>建议</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $healthSuggestions = array();

                                    // 处理每个学生的数据
                                    while ($row = mysql_fetch_assoc($result)) {
                                        $sno = $row['Sno'];
                                        $name = $row['Sname'];
                                        $height = $row['high'];
                                        $weight = $row['weight'];
                                        $fhl = $row['fhl'];
                                        $wsm = $row['wsm'];
                                        $ldty = $row['ldty'];

                                        // 你可以根据自己的需求添加更多的判断和建议
                                        $height_suggestion = "无特殊建议"; // 默认建议
                                        $weight_suggestion = "无特殊建议"; // 默认建议
                                        $fhl_suggestion = "无特殊建议"; // 默认建议
                                        $wsm_suggestion = "无特殊建议"; // 默认建议
                                        $ldty_suggestion = "无特殊建议"; // 默认建议

                                        // 示例：根据身高判断
                                        if ($height < 160) {
                                            $height_suggestion = "建议注意保持适当运动，注意饮食平衡。";
                                        }
                                        // 示例：根据体重判断
                                        if ($weight > 70) {
                                            $weight_suggestion = "建议控制饮食，适当参加有氧运动。";
                                        }

                                        // 示例：根据肺活量判断
                                        if ($fhl < 3000) {
                                            $fhl_suggestion = "建议进行更多有氧运动，提升肺活量。";
                                        }

                                        // 示例：根据50米跑判断
                                        if ($wsm > 10) {
                                            $wsm_suggestion = "建议注意加强短跑训练，提高速度。";
                                        }

                                        // 示例：根据立定跳远判断
                                        if ($ldty < 2) {
                                            $ldty_suggestion = "建议进行腿部力量训练，提高跳远能力。";
                                        }

                                        // 将建议添加到数组
                                        $healthSuggestions[] = array(
                                            'Sno' => $sno,
                                            'Sname' => $name,
                                            'Height_Suggestion' => $height_suggestion,
                                            'Weight_Suggestion' => $weight_suggestion,
                                            'FHL_Suggestion' => $fhl_suggestion,
                                            'WSM_Suggestion' => $wsm_suggestion,
                                            'LDTY_Suggestion' => $ldty_suggestion
                                        );
                                    }

                                    // 打印建议
                                    foreach ($healthSuggestions as $student) {
                                        echo "<tr>";  // 添加一个新行
                                        echo "<td>" . $student['Sno']. "</td>";
                                        echo "<td>" . $student['Sname'] . "</td>";
                                        echo "<td>";
                                        echo "身高：" . $student['Height_Suggestion'] . "<br>";
                                        echo "体重：" . $student['Weight_Suggestion'] . "<br>";
                                        echo "肺活量：" . $student['FHL_Suggestion'] . "<br>";
                                        echo "50米跑：" . $student['WSM_Suggestion'] . "<br>";
                                        echo "立定跳远：" . $student['LDTY_Suggestion'] . "<br>";
                                        echo "</td>";
                                        echo "</tr>";  // 关闭行
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--End Advanced Tables -->
            </div>
        </div>
    </div>
</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="assets/js/jquery.metisMenu.js"></script>
<!-- DATA TABLE SCRIPTS -->
<script src="assets/js/dataTables/jquery.dataTables.js"></script>
<script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
<script>
    $(document).ready(function () {
        $('#dataTables-example').dataTable();
    });
</script>
<!-- CUSTOM SCRIPTS -->
<script src="assets/js/custom.js"></script>
</body>
</html>
